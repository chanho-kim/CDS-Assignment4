To run server, simply run server.java with the input file as argument.

To run client, simply run client.java with the input file as argument.